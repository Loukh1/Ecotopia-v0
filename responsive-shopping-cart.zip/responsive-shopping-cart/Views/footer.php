<!-- FOOTER -->
<footer>
<div class="footer">
      <div class="footer-container">
        <div class="footer-top">
        <h1>Ecotopia</h1>
        <ul class="link-list">
          <li>Home</li>
          <li>Groups</li>
          <li>Events</li>
          <li>Shop</li>
          <li>About</li>
        </ul>
        <div class="social-media-footer">
          <p><i class="fab fa-facebook"></i></p>
          <p><i class="fab fa-instagram"></i></p>
          <p><i class="fab fa-snapchat-square"></i></p>
          <p><i class="fab fa-pinterest-square"></i></p>
          <p><i class="fab fa-youtube"></i></p>
        </div>
      </div>
        <div class="footer-copyright">
          <div class="footer-copyright-left">
            Created by Group 6
          </div>
          <div class="footer-copyright-right">
            &copy;  2021-2022
          </div>
        </div>
      </div>
    </div>
    <!-- /FOOTER -->
</footer>
</html>

